package br.com.fiap.store.dao;

import br.com.fiap.store.bean.Usuario;

public interface UsuarioDAO {

	boolean validarUsuario(Usuario usuario);
	
}